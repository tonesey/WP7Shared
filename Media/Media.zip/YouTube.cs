﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using MyToolkit.Environment;
using MyToolkit.Multimedia;
using MyToolkit.Networking;

#if METRO
using System.Threading.Tasks;
#elif WINDOWS_PHONE
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using MyToolkit.Paging;
using MyToolkit.UI;

#endif

// developed by Rico Suter (http://rsuter.com), http://mytoolkit.codeplex.com
// this code only works with windows phone mango (video urls with query don't work in previous versions)

namespace MyToolkit.Multimedia
{
	public static class YouTube
	{

#if METRO
		public static Task<YouTubeUri> GetVideoUriAsync(string youTubeId, YouTubeQuality maxQuality = YouTubeQuality.Quality480P)
		{
			var task = new TaskCompletionSource<YouTubeUri>();
			GetVideoUri(youTubeId, maxQuality, (u, e) =>
			{
				if (u != null)
					task.SetResult(u);
				else if (e == null)
					task.SetCanceled();
				else
					task.SetException(e);
			});
			return task.Task;
		} 
#endif

		public static Uri GetThumbnailUri(string youTubeId, YouTubeThumbnailSize size = YouTubeThumbnailSize.Medium)
		{
			switch (size)
			{
				case YouTubeThumbnailSize.Small:
					return new Uri("http://img.youtube.com/vi/" + youTubeId + "/default.jpg", UriKind.Absolute);
				case YouTubeThumbnailSize.Medium:
					return new Uri("http://img.youtube.com/vi/" + youTubeId + "/hqdefault.jpg", UriKind.Absolute);
				case YouTubeThumbnailSize.Large:
					return new Uri("http://img.youtube.com/vi/" + youTubeId + "/maxresdefault.jpg", UriKind.Absolute);
			}
			throw new Exception();
		}
		
		private static int GetQualityIdentifier(YouTubeQuality quality)
		{
			switch (quality)
			{
				case YouTubeQuality.Quality480P: return 18;
				case YouTubeQuality.Quality720P: return 22;
				case YouTubeQuality.Quality1080P: return 37;
			}
			throw new ArgumentException("maxQuality");
		}

        //public static HttpResponse GetVideoUri(string youTubeId, YouTubeQuality maxQuality, Action<YouTubeUri, Exception> completed)
        //{
        //    return Http.Get("http://www.youtube.com/watch?v=" + youTubeId + "&nomobile=1", r => OnHtmlDownloaded(r, maxQuality, completed));
        //}


        //ok
        //public static HttpResponse GetVideoUri(string youTubeId, YouTubeQuality maxQuality, Action<YouTubeUri, Exception> completed)
        //{
        //    return Http.Get("http://www.youtube.com/watch?v=" + youTubeId + "&client=mv-google&nomobile=1", r => OnHtmlDownloaded(r, maxQuality,
        //    completed));
        //}

        public static HttpResponse GetVideoUri(string youTubeId, YouTubeQuality maxQuality, Action<YouTubeUri, Exception> completed)
        {
            return Http.Get("http://www.youtube.com/watch?v=" + youTubeId + "&nomobile=1", r => OnHtmlDownloaded(r, maxQuality,
            completed));
        }

		private static void OnHtmlDownloaded(HttpResponse response, YouTubeQuality quality, Action<YouTubeUri, Exception> completed)
		{
			if (response.Successful)
			{
				var urls = new List<YouTubeUri>();
				try
				{

                    //"url_encoded_fmt_stream_map": "sig=29C54E7F7D334EBADAFD5A4A6062E8E4281A9722.5399A3FFE45E5172643E4415D253DB6EF41B0FD6\u0026fallback_host=tc.v3.cache8.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Fcp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dcp%252Cid%252Cip%252Cipbits%252Citag%252Cratebypass%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D43%26ipbits%3D8%26sver%3D3%26ratebypass%3Dyes%26expire%3D1360861878\u0026type=video%2Fwebm%3B+codecs%3D%22vp8.0%2C+vorbis%22\u0026quality=medium\u0026itag=43,sig=8C2CDB703D1B7A9258DEEF10F017E4A6378A2332.D3B69B09438A4F99E60DA277B8ABF51AB2C82A68\u0026fallback_host=tc.v23.cache6.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Falgorithm%3Dthrottle-factor%26cp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dalgorithm%252Cburst%252Ccp%252Cfactor%252Cid%252Cip%252Cipbits%252Citag%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26factor%3D1.25%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D34%26ipbits%3D8%26sver%3D3%26burst%3D40%26expire%3D1360861878\u0026type=video%2Fx-flv\u0026quality=medium\u0026itag=34,sig=5C5D150384C39E7A6D1022917BE1EDBB17FF6A8E.D1D9FE09F85BC8DDFBC9ECCDCA67596D46CC3693\u0026fallback_host=tc.v24.cache1.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Fcp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dcp%252Cid%252Cip%252Cipbits%252Citag%252Cratebypass%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D18%26ipbits%3D8%26sver%3D3%26ratebypass%3Dyes%26expire%3D1360861878\u0026type=video%2Fmp4%3B+codecs%3D%22avc1.42001E%2C+mp4a.40.2%22\u0026quality=medium\u0026itag=18,sig=BCBA0F3EC9BAFC6CD11CCD1C0EB142DAE5DC19AF.989426192B7CBC6CD29F8FE618435985E0F189FA\u0026fallback_host=tc.v21.cache4.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Falgorithm%3Dthrottle-factor%26cp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dalgorithm%252Cburst%252Ccp%252Cfactor%252Cid%252Cip%252Cipbits%252Citag%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26factor%3D1.25%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D5%26ipbits%3D8%26sver%3D3%26burst%3D40%26expire%3D1360861878\u0026type=video%2Fx-flv\u0026quality=small\u0026itag=5,sig=52FC1D91384B5F59490E9068DD05C86643C62D7E.2E3BDEB867FD0E9C6EA09D504CBBB5C3E501644D\u0026fallback_host=tc.v19.cache8.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Falgorithm%3Dthrottle-factor%26cp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dalgorithm%252Cburst%252Ccp%252Cfactor%252Cid%252Cip%252Cipbits%252Citag%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26factor%3D1.25%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D36%26ipbits%3D8%26sver%3D3%26burst%3D40%26expire%3D1360861878\u0026type=video%2F3gpp%3B+codecs%3D%22mp4v.20.3%2C+mp4a.40.2%22\u0026quality=small\u0026itag=36,sig=079CF67DF113A1BB21302941BDE58CBDC46616BA.77506790A8918BC75732B7FB134FB57A9381B194\u0026fallback_host=tc.v9.cache6.c.youtube.com\u0026url=http%3A%2F%2Fr7---sn-o5hxm-4jvl.c.youtube.com%2Fvideoplayback%3Falgorithm%3Dthrottle-factor%26cp%3DU0hVRVhRT19MUkNONV9QS1NJOjI1eUFCcWxOVzRF%26id%3D9c2122eb825dd141%26upn%3DN047qOZKiGs%26mv%3Dm%26source%3Dyoutube%26ms%3Dau%26sparams%3Dalgorithm%252Cburst%252Ccp%252Cfactor%252Cid%252Cip%252Cipbits%252Citag%252Csource%252Cupn%252Cexpire%26mt%3D1360839493%26newshard%3Dyes%26factor%3D1.25%26key%3Dyt1%26ip%3D151.47.76.144%26fexp%3D912301%252C923501%252C904448%252C916611%252C920704%252C912806%252C902000%252C922403%252C922405%252C929901%252C913605%252C925006%252C908529%252C920201%252C930101%252C911116%252C926403%252C910221%252C901451%252C919114%26itag%3D17%26ipbits%3D8%26sver%3D3%26burst%3D40%26expire%3D1360861878\u0026type=video%2F3gpp%3B+codecs%3D%22mp4v.20.3%2C+mp4a.40.2%22\u0026quality=small\u0026itag=17"

                    //orig
					//var match = Regex.Match(response.Response, "url_encoded_fmt_stream_map=(.*?)(&|\")");
                    var match = Regex.Match(response.Response, "url_encoded_fmt_stream_map(.*,)");
					var data = Uri.UnescapeDataString(match.Groups[1].Value);


//                 ": "fallback_host=tc.v3.cache8.c.youtube.com\u0026itag=43\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=43&source=youtube&expire=1360865478&ratebypass=yes&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&ip=151.47.76.144&sparams=cp%2Cid%2Cip%2Cipbits%2Citag%2Cratebypass%2Csource%2Cupn%2Cexpire&id=9c2122eb825dd141&mv=m&sver=3&ms=au&upn=9yXwmUnztzQ&mt=1360840032\u0026quality=medium\u0026type=video/webm;+codecs="vp8.0,+vorbis"\u0026sig=55959FBEEAEA363FBE880BD68FF4D895EAC5F9BE.7C3B743D90F850DF5A4D1AC71A89885A0A5A94C2,fallback_host=tc.v23.cache6.c.youtube.com\u0026itag=34\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=34&source=youtube&burst=40&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&mv=m&expire=1360865478&upn=9yXwmUnztzQ&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&factor=1.25&ip=151.47.76.144&algorithm=throttle-factor&id=9c2122eb825dd141&sparams=algorithm%2Cburst%2Ccp%2Cfactor%2Cid%2Cip%2Cipbits%2Citag%2Csource%2Cupn%2Cexpire&sver=3&ms=au&mt=1360840032\u0026quality=medium\u0026type=video/x-flv\u0026sig=9067D65F0F52BD2F587483282C6F0449A697A5C4.8961B2FD7CECBE080A8441CD3FFC5FDF0AA2201A,fallback_host=tc.v24.cache1.c.youtube.com\u0026itag=18\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=18&source=youtube&expire=1360865478&ratebypass=yes&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&ip=151.47.76.144&sparams=cp%2Cid%2Cip%2Cipbits%2Citag%2Cratebypass%2Csource%2Cupn%2Cexpire&id=9c2122eb825dd141&mv=m&sver=3&ms=au&upn=9yXwmUnztzQ&mt=1360840032\u0026quality=medium\u0026type=video/mp4;+codecs="avc1.42001E,+mp4a.40.2"\u0026sig=778188E420C2AA8E9BE59F53D549AAD9FE5C2522.56B0119C924DA5D48FD0AF77B0D69D485AD0A27C,fallback_host=tc.v21.cache4.c.youtube.com\u0026itag=5\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=5&source=youtube&burst=40&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&mv=m&expire=1360865478&upn=9yXwmUnztzQ&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&factor=1.25&ip=151.47.76.144&algorithm=throttle-factor&id=9c2122eb825dd141&sparams=algorithm%2Cburst%2Ccp%2Cfactor%2Cid%2Cip%2Cipbits%2Citag%2Csource%2Cupn%2Cexpire&sver=3&ms=au&mt=1360840032\u0026quality=small\u0026type=video/x-flv\u0026sig=77579C6E8DAEABDD145A0F8B32EFB617697E3364.C27EAEA9B1F4606356C04FAB36E3D7CE2514CB46,fallback_host=tc.v19.cache8.c.youtube.com\u0026itag=36\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=36&source=youtube&burst=40&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&mv=m&expire=1360865478&upn=9yXwmUnztzQ&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&factor=1.25&ip=151.47.76.144&algorithm=throttle-factor&id=9c2122eb825dd141&sparams=algorithm%2Cburst%2Ccp%2Cfactor%2Cid%2Cip%2Cipbits%2Citag%2Csource%2Cupn%2Cexpire&sver=3&ms=au&mt=1360840032\u0026quality=small\u0026type=video/3gpp;+codecs="mp4v.20.3,+mp4a.40.2"\u0026sig=D7AD7463DD16CD6FE2F42D8210947CAC17C87A5F.92F2D2CB44C7959432E36BF72278F3F405DB1E9E,fallback_host=tc.v9.cache6.c.youtube.com\u0026itag=17\u0026url=http://r7---sn-o5hxm-4jvl.c.youtube.com/videoplayback?key=yt1&itag=17&source=youtube&burst=40&cp=U0hVRVhRU19MUkNONV9QS1dFOnNyMllpV1drWnlV&mv=m&expire=1360865478&upn=9yXwmUnztzQ&ipbits=8&newshard=yes&fexp=916605%2C919330%2C908477%2C914026%2C920704%2C912806%2C902000%2C922403%2C922405%2C929901%2C913605%2C925006%2C908529%2C920201%2C930101%2C911116%2C926403%2C910221%2C901451%2C919114&factor=1.25&ip=151.47.76.144&algorithm=throttle-factor&id=9c2122eb825dd141&sparams=algorithm%2Cburst%2Ccp%2Cfactor%2Cid%2Cip%2Cipbits%2Citag%2Csource%2Cupn%2Cexpire&sver=3&ms=au&mt=1360840032\u0026quality=small\u0026type=video/3gpp;+codecs="mp4v.20.3,+mp4a.40.2"\u0026sig=D3297CC89DA1EF5E170075C87C16815304DA7D56.CDAD505516E140B762694EDC0BFC95DBD4A9A351", "watermark": ",http:\/\/s.ytimg.com\/yts\/img\/watermark\/youtube_watermark-vflHX6b6E.png,http:\/\/s.ytimg.com\/yts\/img\/watermark\/youtube_hd_watermark-vflAzLcD6.png", "account_playback_token": "", "pltype": "contentugc", "ptk": "youtube_none", "title": "Pingu babysitter", "share_icons": "http:\/\/s.ytimg.com\/yts\/swfbin\/sharing-vflsK6yOc.swf", "no_get_video_log": "1", "vq": "auto", "hl": "it_IT", "sk": "MbWojcQJntjDkJZrFZ6Wp4dx6xISyt-cC", "t": "vjVQa1PpcFOGOV6NgGL8Z40gZPH4KzN0Ei87OngqVJ0=", "enablecsi": "1", "is_html5_mobile_device": false, "plid": "AATVrUYVpSn_lrsE", "tmi": "1", "timestamp": 1360840088, "fmt_list": "43\/640x360\/99\/0\/0,34\/640x360\/9\/0\/115,18\/640x360\/9\/0\/115,5\/320x240\/7\/0\/0,36\/320x240\/99\/0\/0,17\/176x144\/99\/0\/0", "playlist_module": "http:\/\/s.ytimg.com\/yts\/swfbin\/playlist_module-vfl6fU1Qw.swf", "autohide": "2", "allow_embed": 1, "fexp": "916605,919330,908477,914026,920704,912806,902000,922403,922405,929901,913605,925006,908529,920201,930101,911116,926403,910221,901451,919114", "length_seconds": 323, "keywords": "Pingu,babysits,YouTube", "tk": "OwfhY0e3UlXbXqMtmLH-ydOVQKSnsO5uIEBvGisBULNug03xOISg5g==", "sendtmp": "1", "video_id": "nCEi64Jd0UE", "enablejsapi": 1, "storyboard_spec": "http:\/\/i3.ytimg.com\/sb\/nCEi64Jd0UE\/storyboard3_L$L\/$N.jpg|48#27#100#10#10#0#default#Z_CIPx02hZDBBV_GvpypnRSoGHQ|60#45#66#10#10#5000#M$M#690qZtLbxvk0W2uNhS3Pdqdz4AQ|120#90#66#5#5#5000#M$M#IJSEfeJCzc51HPe1owdyNiC_k34", "referrer": null, "csi_page_type": "watch7"}, "assets": {"css": "http:\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflwOI78o.css", "js": "http:\/\/s.ytimg.com\/yts\/jsbin\/html5player-vflgLqI8C.js", "css_actions": "http:\/\/s.ytimg.com\/yts\/cssbin\/www-player-actions-vflAdyzYh.css", "html": "\/html5_player_template"}, "sts": 136065218906,
                    //orig
                    //var arr = data.Split(',');
                    var arr = data.Split('\u0026');
					foreach (var d in arr)
					{
						var url = "";
						var signature = "";
						var tuple = new YouTubeUri();
						foreach (var p in d.Split('&'))
						{
							var index = p.IndexOf('=');
							if (index != -1 && index < p.Length)
							{
								try
								{
									var key = p.Substring(0, index);
									var value = Uri.UnescapeDataString(p.Substring(index + 1));
									if (key == "url")
										url = value;
									else if (key == "itag")
										tuple.Itag = int.Parse(value);
									else if (key == "type" && value.Contains("video/mp4"))
										tuple.Type = value;
									else if (key == "sig")
										signature = value;
								}
								catch { }
							}
						}

						tuple.url = url + "&signature=" + signature;
                        if (tuple.IsValid)
                        {
                            urls.Add(tuple);
                        }
					}

					var itag = GetQualityIdentifier(quality);
                    foreach (var u in urls.Where(u => u.Itag > itag).ToArray())
                    {
                        urls.Remove(u);
                    }
				}
				catch (Exception ex)
				{
                    if (completed != null)
                    {
                        completed(null, ex);
                    }
					return; 
				}

				var entry = urls.OrderByDescending(u => u.Itag).FirstOrDefault();
				if (entry != null)
				{
                    if (completed != null)
                    {
                        completed(entry, null);
                    }
				}
                else if (completed != null)
                {
                    completed(null, new Exception("no_video_urls_found"));
                }
			}
            else if (completed != null)
            {
                completed(null, response.Exception);
            }
		}

		public class YouTubeUri
		{
			internal string url;

			public Uri Uri { get { return new Uri(url, UriKind.Absolute); } }
			public int Itag { get; set; }
			public string Type { get; set; }

			public bool IsValid
			{
				get { return url != null && Itag > 0 && Type != null; }
			}
		}
		
		#region Phone

#if WINDOWS_PHONE

		public static HttpResponse Play(string youTubeId, YouTubeQuality maxQuality = YouTubeQuality.Quality480P, Action<Exception> completed = null)
		{
			return GetVideoUri(youTubeId, maxQuality, (entry, e) =>
			{
				if (e != null)
			    {
					if (completed != null)
						completed(e);
			    }
				else
			    {
					if (completed != null)
						completed(null);

					if (entry != null)
					{
						 var launcher = new MediaPlayerLauncher
						 {
							 Controls = MediaPlaybackControls.All,
							 Media = entry.Uri
						 };
						 launcher.Show();
					}
			    }
			});
		}


		private static HttpResponse httpResponse;
		private static PageDeactivator oldState;

		/// <summary>
		/// This method disables the current page and shows a progress indicator until the youtube movie url has been loaded and starts
		/// </summary>
		/// <param name="youTubeId"></param>
		/// <param name="manualActivatePage">if true add YouTube.CancelPlay() in OnNavigatedTo() of the page (better)</param>
		/// <param name="maxQuality"></param>
		/// <param name="completed"></param>
		public static void Play(string youTubeId, bool manualActivatePage, YouTubeQuality maxQuality = YouTubeQuality.Quality480P, Action<Exception> completed = null)
		{
			lock (typeof(YouTube))
			{
				if (oldState != null)
					return;

				if (SystemTray.ProgressIndicator == null)
					SystemTray.ProgressIndicator = new ProgressIndicator();

				SystemTray.ProgressIndicator.IsVisible = true;
				SystemTray.ProgressIndicator.IsIndeterminate = true; 

				var page = PhonePage.CurrentPage;
				oldState = PageDeactivator.Inactivate();
				httpResponse = Play(youTubeId, YouTubeQuality.Quality480P, ex => Deployment.Current.Dispatcher.BeginInvoke(
					delegate
					{
						if (page == PhonePage.CurrentPage) // !user navigated away
							CancelPlay(manualActivatePage);

						if (completed != null)
							completed(ex);
					}));
			}
		}

		/// <summary>
		/// call this in OnBackKeyPress() of the page: 
		/// e.Cancel = YouTube.CancelPlay();
		/// or in OnNavigatedTo() and use manualActivatePage = true
		/// </summary>
		/// <returns></returns>
		public static bool CancelPlay()
		{
			return CancelPlay(false);
		}

		private static bool CancelPlay(bool manualActivate)
		{
			lock (typeof(YouTube))
			{
				if (oldState == null && httpResponse == null)
					return false;

				if (httpResponse != null)
				{
					httpResponse.Abort();
					httpResponse = null;
				}

				if (!manualActivate && oldState != null)
				{
					oldState.Revert();
					SystemTray.ProgressIndicator.IsVisible = false;
					oldState = null;
				}

				return true;
			}
		}

#endif
		#endregion
	}
}
